print("~Your Savings Calculator~")

user_input = input("How much do you make per hour?")

hours_worked = input("How many hours do you work a day?")

daily_savings= int(user_input) * int(hours_worked)

print("This is your daily savings:",daily_savings)

days_worked= input("How many days do you work a week?")
weekly_savings = int(daily_savings)*int(days_worked)

print("Your savings for the week are:", weekly_savings)


monthly_savings = int(weekly_savings)*4
print("Your savings for the month is:", monthly_savings)

yearly_savings = int(monthly_savings)*52
print("Your savings for the year:", yearly_savings)
